var searchData=
[
  ['m_5fid',['m_Id',['../class_item_type.html#a8901a6a0f86149c6f24f4cc56251d58a',1,'ItemType']]],
  ['m_5fsmanufacturer',['m_sManufacturer',['../class_item_type.html#a0613315339d1203dddd5043dec848d52',1,'ItemType']]],
  ['m_5fsname',['m_sName',['../class_item_type.html#a360e90ab637b2463cf8fae3563612316',1,'ItemType']]]
];
