#include "FolderType.hpp"

// Set Set Folder Name from keyboard.
void FolderType::SetNameFromKB(){
	std::cout << "\t Name : ";
	std::cin >> this->fdName;
}


