var searchData=
[
  ['makeempty',['MakeEmpty',['../class_c_heap_base.html#ab051cb29fb90aae4730207a5663cc916',1,'CHeapBase']]]
];
