var searchData=
[
  ['searchitem',['SearchItem',['../class_application.html#a7305261c9493d3896cc8514528ca8703',1,'Application']]],
  ['setname',['SetName',['../class_folder_type.html#a02256df5c178c3f3d9185ae77d0d4806',1,'FolderType']]],
  ['setnamefromkb',['SetNameFromKB',['../class_folder_type.html#aab0cecfaf031f040a8546778e75d5d96',1,'FolderType']]],
  ['swap',['Swap',['../class_c_heap_base.html#a4e44ab4b072982b1f9703a21f40caf74',1,'CHeapBase']]]
];
