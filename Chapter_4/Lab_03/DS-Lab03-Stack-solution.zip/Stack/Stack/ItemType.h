/**
*	@breif	Typedef for stack testing simply.
*/
typedef int ItemType;