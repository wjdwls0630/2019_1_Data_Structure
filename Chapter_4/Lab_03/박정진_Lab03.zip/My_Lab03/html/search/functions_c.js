var searchData=
[
  ['setcreatedtime',['SetCreatedTime',['../class_folder_type.html#a87b6e4fc0b88b9848647119a4da4aaa0',1,'FolderType']]],
  ['setname',['SetName',['../class_folder_type.html#a02256df5c178c3f3d9185ae77d0d4806',1,'FolderType']]],
  ['setnamefromkb',['SetNameFromKB',['../class_folder_type.html#aab0cecfaf031f040a8546778e75d5d96',1,'FolderType']]],
  ['setpath',['SetPath',['../class_folder_type.html#a91da23c4b654f87ca5d7902e9847ee42',1,'FolderType']]],
  ['setpathfromkb',['SetPathFromKB',['../class_folder_type.html#a12a0f09ce6c48470e1e24bd33467206c',1,'FolderType']]],
  ['setsubfoldernumber',['SetSubFolderNumber',['../class_folder_type.html#a119b75ff7351fc8075a41df9617932ee',1,'FolderType']]],
  ['sortedlist',['SortedList',['../class_sorted_list.html#a562e09a9c8ed5c876994cafd6224c992',1,'SortedList::SortedList(int size=MAXLISTSIZE)'],['../class_sorted_list.html#a83b3a1ee2112791782f5463ea51e0d2d',1,'SortedList::SortedList(const SortedList &amp;sl)']]],
  ['stack',['Stack',['../class_stack.html#a38f090d79585103f2a09d54c04a896e4',1,'Stack::Stack(int size=MAXSTACKSIZE)'],['../class_stack.html#ae52d263c4b6f5b955811b4a163e9bc48',1,'Stack::Stack(const Stack &amp;st)']]]
];
