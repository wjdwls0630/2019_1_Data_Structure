var searchData=
[
  ['makeempty',['MakeEmpty',['../class_circular_queue.html#a89f66c0611c26e7bc88ae2aa149594cf',1,'CircularQueue::MakeEmpty()'],['../class_sorted_list.html#a2c2142ab41a582b40bb771fe6bdf89aa',1,'SortedList::MakeEmpty()'],['../class_stack.html#aeda320cad6fbd153eff09ea155d0fea1',1,'Stack::MakeEmpty()']]]
];
