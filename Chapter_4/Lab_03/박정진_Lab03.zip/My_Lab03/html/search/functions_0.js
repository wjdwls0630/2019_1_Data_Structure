var searchData=
[
  ['add',['Add',['../class_sorted_list.html#a6ca820f045a25002eeb63b1f4bf30428',1,'SortedList']]],
  ['addfolder',['AddFolder',['../class_folder_type.html#a767c359c655fb55669dcf01874ca5541',1,'FolderType']]],
  ['addrecentlyfolder',['AddRecentlyFolder',['../class_application.html#aca30c9de2ff255e03a6fe34dbbf5d590',1,'Application']]],
  ['application',['Application',['../class_application.html#afa8cc05ce6b6092be5ecdfdae44e05f8',1,'Application']]]
];
