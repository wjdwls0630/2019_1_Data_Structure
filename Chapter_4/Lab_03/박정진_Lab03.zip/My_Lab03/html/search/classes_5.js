var searchData=
[
  ['invalidoperation',['InvalidOperation',['../class_invalid_operation.html',1,'']]]
];
