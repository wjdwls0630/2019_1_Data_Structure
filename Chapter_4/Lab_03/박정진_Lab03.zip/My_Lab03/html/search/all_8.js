var searchData=
[
  ['newfolder',['NewFolder',['../class_application.html#a97a4b7d83497b96b8485344a40d55712',1,'Application']]],
  ['nohistory',['NoHistory',['../class_no_history.html',1,'']]]
];
