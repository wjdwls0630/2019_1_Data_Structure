var searchData=
[
  ['pop',['Pop',['../class_stack.html#a197a49c3d95c29649cf35f756999c612',1,'Stack']]],
  ['push',['Push',['../class_stack.html#ac06f50246844e8e72affd1ad2a592086',1,'Stack']]]
];
