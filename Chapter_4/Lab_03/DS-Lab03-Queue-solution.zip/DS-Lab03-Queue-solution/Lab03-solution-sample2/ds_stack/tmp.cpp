#include "tmp.h"


tmp::tmp(void)
{
	id=1;
}


tmp::~tmp(void)
{
}
