/**
*	@brief	Typedef for Queue testing simply.
*/
typedef int ItemType;