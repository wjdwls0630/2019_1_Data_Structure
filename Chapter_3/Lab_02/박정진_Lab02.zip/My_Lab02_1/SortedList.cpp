#include "SortedList.hpp"



// Make list empty.
template <typename T>
void SortedList<T>::MakeEmpty(){
	this->m_Length = 0;
}


// Get a number of records in current list.
template <typename T>
int SortedList<T>::GetLength() const{
	return this->m_Length;
}


// Check capacity of list is full.
template <typename T>
bool SortedList<T>::IsFull() const{
	if(m_Length > MAXSIZE - 1)
		return true;
	else
		return false;
}

//Check capacity of list is empty.
template <typename T>
bool SortedList<T>::IsEmpty() const{
	if (this->m_Length==0) {
		return true;
	} else {
		return false;
	}
}

//Rellocate dynamic Array, Increase Capactiy by 10.
template <typename T>
T* SortedList<T>::ReAlloc(){
	//declare new dynamic array to copy
	T* n_Array= new T[this->maxSize+10];

	//use std::copy to copy
	std::copy(this->m_Array,this->m_Array+this->maxSize,n_Array);

	//delete old Array
	delete [] this->m_Array;

	//set new Array, size
	this->m_Array=n_Array;
	this->maxSize+=10;
	return this->m_Array;
}


// add a new data into list.
template <typename T>
int SortedList<T>::Add(T data){
	if (this->IsFull()) {
		std::cout << "\tReallocating..." << '\n';
		this->ReAlloc();
		std::cout << "\tReallocating Succeed!" << '\n';
	}
	this->ResetList();

	T Temp_Data;
	for (int i = 0; i < this->m_Length; i++) {
		this->GetNextItem(Temp_Data);
		//Compare data and m_Array item
		if (data<Temp_Data) {
			//move items by one index to backward
			for (int j = this->m_CurPointer; j < this->m_Length; j++) {
				this->m_Array[j+1]=this->m_Array[j];
			}
			this->m_Array[this->m_CurPointer]=data;
			this->m_length++;
			return 1;
		}
	}

	//if data is biggest in the list
	this->m_Array[this->m_Length]=data;
	this->m_length++;
	return 1;
}


// Initialize list iterator.
template <typename T>
void SortedList<T>::ResetList(){
	this->m_CurPointer = -1;
}


// move list iterator to the next item in list and get that item.
template <typename T>
int SortedList<T>::GetNextItem(T& data){
	this->m_CurPointer++;	// list pointer ����
	if(this->m_CurPointer == this->maxSize)	// end of list�̸� -1�� ����
		return -1;
	data = this->m_Array[this->m_CurPointer];	// ���� list pointer�� ���ڵ带 ����
	return this->m_CurPointer;
}

// get the data which has same id in the list.(Sequential Search)
template <typename T>
int SortedList<T>::Get(T& data){
	T Temp_Data;
	this->ResetList(); // Initialize the list pointer
	for (int i = 0; i < this->m_Length; i++) {
		this->GetNextItem(Temp_Data);
		if (data==Temp_Data) { // if data and iter has same id,
			data=Temp_Data; // deep copy data from iter
			return 1; // return the data index
		}
	}
	return -1;
}

// delete the data which you want to delete in the list.
template <typename T>
int SortedList<T>::Delete(T data){
	try {
		// check list is empty
		if (this->IsEmpty()) {
			throw EmptyList();
		} else{
			// get the data you want to delete from the list
			if (this->Get(data)==-1) { // if there is no same id in the list, return 0;
				throw DataNotFound();
			} else{
				for (int i = this->m_CurPointer; i < this->m_Length-1; i++) {
					this->m_Array[i]=this->m_Array[i+1];
				} // if data is deleted, data which are backward position than deleted one move one index forward
				this->m_Length--;
				return 1;
			}
		}
	} catch(std::exception &ex){
		std::cout << ex.what() << '\n';
		return 0;
	}
}

// update the data which you want to update in the list.
template <typename T>
int SortedList<T>::Replace(T data){
	try{
		// get the data you want to delete from the list
		if (this->Get(data)==-1) { // if there is no same id in the list, return 0;
			throw DataNotFound();
		} else{
			data.SetRecordFromKB(); // set the new record on data
			this->m_Array[this->m_CurPointer]=data; // put updated data in same index
			return 1;
		}
	} catch(std::exception &ex){
		std::cout << ex.what() << '\n';
		return 0;
	}
}
