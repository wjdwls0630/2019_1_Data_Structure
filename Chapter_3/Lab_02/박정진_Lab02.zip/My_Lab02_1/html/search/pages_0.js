var searchData=
[
  ['sorted_20list_2e',['Sorted list.',['../index.html',1,'']]]
];
