var searchData=
[
  ['foldertype',['FolderType',['../class_folder_type.html#a0c85962e9c944a07e7386174ad97ea5a',1,'FolderType']]]
];
