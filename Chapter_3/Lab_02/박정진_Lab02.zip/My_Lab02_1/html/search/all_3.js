var searchData=
[
  ['emptyfolder',['EmptyFolder',['../class_empty_folder.html',1,'']]]
];
