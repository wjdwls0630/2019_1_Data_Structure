var searchData=
[
  ['filenotfound',['FileNotFound',['../class_file_not_found.html',1,'']]],
  ['foldernotfound',['FolderNotFound',['../class_folder_not_found.html',1,'']]],
  ['folderoverlap',['FolderOverLap',['../class_folder_over_lap.html',1,'']]],
  ['foldertype',['FolderType',['../class_folder_type.html',1,'FolderType'],['../class_folder_type.html#a0c85962e9c944a07e7386174ad97ea5a',1,'FolderType::FolderType()']]]
];
