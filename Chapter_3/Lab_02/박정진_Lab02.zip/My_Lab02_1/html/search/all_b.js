var searchData=
[
  ['sorted_20list_2e',['Sorted list.',['../index.html',1,'']]],
  ['setallinfo',['SetAllInfo',['../class_folder_type.html#a51d866b3e79931c75d2551ee04c0ad69',1,'FolderType']]],
  ['setcreatedtime',['SetCreatedTime',['../class_folder_type.html#a87b6e4fc0b88b9848647119a4da4aaa0',1,'FolderType']]],
  ['setdirection',['SetDirection',['../class_sorted_list.html#a39f12b801cce773f89662cbad5a258b2',1,'SortedList']]],
  ['setmodifiedtime',['SetModifiedTime',['../class_folder_type.html#a0977c2baa95eac907c975c8c07722055',1,'FolderType']]],
  ['setname',['SetName',['../class_folder_type.html#a02256df5c178c3f3d9185ae77d0d4806',1,'FolderType']]],
  ['setnamefromkb',['SetNameFromKB',['../class_folder_type.html#aab0cecfaf031f040a8546778e75d5d96',1,'FolderType']]],
  ['setpath',['SetPath',['../class_folder_type.html#a91da23c4b654f87ca5d7902e9847ee42',1,'FolderType']]],
  ['setpathfromkb',['SetPathFromKB',['../class_folder_type.html#a12a0f09ce6c48470e1e24bd33467206c',1,'FolderType']]],
  ['setsubfoldernumber',['SetSubFolderNumber',['../class_folder_type.html#a119b75ff7351fc8075a41df9617932ee',1,'FolderType']]],
  ['sortedlist',['SortedList',['../class_sorted_list.html',1,'SortedList&lt; T &gt;'],['../class_sorted_list.html#ab0ced8ba147cc0aff031cf28b21c4dc3',1,'SortedList::SortedList(int size=MAXSIZE)'],['../class_sorted_list.html#ab52aff617fea11ffeda9c04f9c7dc2b8',1,'SortedList::SortedList(const int &amp;Direction, int size=MAXSIZE)']]],
  ['sortedlist_3c_20foldertype_20_3e',['SortedList&lt; FolderType &gt;',['../class_sorted_list.html',1,'']]]
];
