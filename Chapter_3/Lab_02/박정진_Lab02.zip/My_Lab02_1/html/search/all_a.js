var searchData=
[
  ['readdatafromfile',['ReadDataFromFile',['../class_application.html#abfb951aeecc63a5e65ea2bbd4e83d96e',1,'Application::ReadDataFromFile()'],['../class_folder_type.html#a728aab2fd419721da2fdebb2be254a3a',1,'FolderType::ReadDataFromFile()']]],
  ['realloc',['ReAlloc',['../class_sorted_list.html#ae8e59f4fcf13e589080fc62467d37066',1,'SortedList']]],
  ['replace',['Replace',['../class_sorted_list.html#a5be0efa110f2d92c203e7872fd04e62a',1,'SortedList']]],
  ['resetlist',['ResetList',['../class_sorted_list.html#aae02ef76c5185e249c3545a42e1d38c9',1,'SortedList']]],
  ['retrievefolderbyname',['RetrieveFolderByName',['../class_application.html#acf410587317cd7ec9c31586f57145a0c',1,'Application::RetrieveFolderByName()'],['../class_folder_type.html#a96ed5c758b3cd662fd431b58a8870279',1,'FolderType::RetrieveFolderByName()']]],
  ['retrievefolderptrbyname',['RetrieveFolderPtrByName',['../class_folder_type.html#a3e3fbda0682eb482b3c606b106b8832b',1,'FolderType']]],
  ['retrievefoldersbyname',['RetrieveFoldersByName',['../class_folder_type.html#aa200b5929565601cac710383af3b2605',1,'FolderType']]],
  ['run',['Run',['../class_application.html#aaf09cd6cb412086dc039e28cdb059f0d',1,'Application']]]
];
