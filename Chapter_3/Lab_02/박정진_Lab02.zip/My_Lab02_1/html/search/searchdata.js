var indexSectionsWithContent =
{
  0: "acdefgimnorsw~",
  1: "acdefins",
  2: "acdfgimnorsw~",
  3: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Pages"
};

