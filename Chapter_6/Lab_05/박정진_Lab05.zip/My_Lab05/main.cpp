/**
*	@mainpage	DoublySortedLinkedList.
*				This is a simple example of Lab05 on data structures course.<br>
*
*	@date	2019.05.02
*	@author	ParkJungJin
*/

#include "BaseApplication.hpp"

/**
*	program main function for data structures course.
*/
int main()
{
	BaseApplication app;	// Program application
	app.Run();			// run program

	return 0;
}
