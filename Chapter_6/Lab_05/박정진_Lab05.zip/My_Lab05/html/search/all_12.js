var searchData=
[
  ['whatis',['WhatIs',['../class_file_type.html#ac43b127052f61e40897bc40f7cb800d8',1,'FileType::WhatIs()'],['../class_folder_type.html#a452622f67fb6d993dd3b5c74c754b1a9',1,'FolderType::WhatIs()'],['../class_item_type.html#afd795276499e9f8a5ce163d51694440f',1,'ItemType::WhatIs()']]]
];
