var searchData=
[
  ['resetfolderkey',['ResetFolderKey',['../class_folder_type.html#a7121baee91e41e0cae92c4541e715bbe',1,'FolderType']]],
  ['resettohead',['ResetToHead',['../class_doubly_iterator.html#a0f0b85da014690e819951a8e377ad8b8',1,'DoublyIterator']]],
  ['resettotail',['ResetToTail',['../class_doubly_iterator.html#aaab24f4525f4bf6b8fdf2aece59f91bb',1,'DoublyIterator']]],
  ['retrievefilebyname',['RetrieveFileByName',['../class_folder_type.html#a7afb0c8f8068f546d3de46816b60c64e',1,'FolderType']]],
  ['retrievefileptrbyname',['RetrieveFilePtrByName',['../class_folder_type.html#a8b5028594bd1152e468d1d824472c155',1,'FolderType']]],
  ['retrievefolderbyname',['RetrieveFolderByName',['../class_folder_type.html#a96ed5c758b3cd662fd431b58a8870279',1,'FolderType']]],
  ['retrievefolderptrbyname',['RetrieveFolderPtrByName',['../class_folder_type.html#a90b2b78dc63a1ca0623fa91fa512429d',1,'FolderType']]],
  ['retrieveitemsbyname',['RetrieveItemsByName',['../class_folder_type.html#aa510fd12acb7cc3408e24eb28657c810',1,'FolderType']]],
  ['run',['Run',['../class_base_application.html#a8f2ce8add401a3b537f041df9f7ef978',1,'BaseApplication::Run()'],['../class_file_type.html#aa761615014e9d4ce339c0163a38b1251',1,'FileType::Run()'],['../class_j_p_g_application.html#a6c996573198fd5935a04276c2308e9c5',1,'JPGApplication::Run()'],['../class_text_application.html#ae6ec0ddfac6060639afa12feb78d73b7',1,'TextApplication::Run()']]],
  ['runfile',['RunFile',['../class_base_application.html#adecbc4b863bc92fc6dbc79efcf7ae7a6',1,'BaseApplication']]]
];
