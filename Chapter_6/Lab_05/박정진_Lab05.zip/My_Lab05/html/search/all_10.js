var searchData=
[
  ['textapplication',['TextApplication',['../class_text_application.html',1,'TextApplication'],['../class_text_application.html#af51897dce499f3b4797ff2e7a845e0bb',1,'TextApplication::TextApplication()']]],
  ['top',['Top',['../class_linked_history_stack.html#a65836d67e4f25754df75a69c344e7d79',1,'LinkedHistoryStack']]],
  ['topptr',['TopPtr',['../class_linked_history_stack.html#a964980ea6d5ae2d0a68e1678a9c8b2ce',1,'LinkedHistoryStack']]]
];
