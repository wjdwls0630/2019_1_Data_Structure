var searchData=
[
  ['textapplication',['TextApplication',['../class_text_application.html',1,'']]]
];
