var searchData=
[
  ['jpgapplication',['JPGApplication',['../class_j_p_g_application.html',1,'JPGApplication'],['../class_j_p_g_application.html#a622e7006093b08f714e06ddaca98572f',1,'JPGApplication::JPGApplication()']]]
];
