var searchData=
[
  ['baseapplication',['BaseApplication',['../class_base_application.html',1,'BaseApplication'],['../class_base_application.html#ab1ef66f8f9dd1496d06dcc05e24e0b92',1,'BaseApplication::BaseApplication()']]]
];
