var searchData=
[
  ['whatis',['WhatIs',['../class_file_type.html#ac43b127052f61e40897bc40f7cb800d8',1,'FileType::WhatIs()'],['../class_folder_type.html#a452622f67fb6d993dd3b5c74c754b1a9',1,'FolderType::WhatIs()'],['../class_item_type.html#a97ec206735474ac6d92e90e0225b3fce',1,'ItemType::WhatIs()'],['../class_j_p_g_file_type.html#a9cfbda7cfcfa31e8babdcb9dce2a3fd7',1,'JPGFileType::WhatIs()'],['../class_m_p3_file_type.html#ad229ed1540f3e910ad05b5ad1932688b',1,'MP3FileType::WhatIs()'],['../class_text_file_type.html#aa95bda99155ca0bf3b83888a03ec8c51',1,'TextFileType::WhatIs()']]]
];
