var searchData=
[
  ['jpgapplication',['JPGApplication',['../class_j_p_g_application.html',1,'']]],
  ['jpgfiletype',['JPGFileType',['../class_j_p_g_file_type.html',1,'']]]
];
