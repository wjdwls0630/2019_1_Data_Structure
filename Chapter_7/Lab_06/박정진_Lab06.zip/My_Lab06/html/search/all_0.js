var searchData=
[
  ['add',['Add',['../class_d_s_linked_list.html#a372a495363bf37c0cc864f7fa67bdba1',1,'DSLinkedList']]],
  ['addrecentitem',['AddRecentItem',['../class_base_application.html#a3e8c878235dea443d9f7a889f02a72d2',1,'BaseApplication']]]
];
