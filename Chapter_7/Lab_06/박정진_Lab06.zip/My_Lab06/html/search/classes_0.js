var searchData=
[
  ['baseapplication',['BaseApplication',['../class_base_application.html',1,'']]]
];
