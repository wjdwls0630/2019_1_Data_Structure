var searchData=
[
  ['jpgapplication',['JPGApplication',['../class_j_p_g_application.html',1,'JPGApplication'],['../class_j_p_g_application.html#a622e7006093b08f714e06ddaca98572f',1,'JPGApplication::JPGApplication()']]],
  ['jpgfiletype',['JPGFileType',['../class_j_p_g_file_type.html',1,'JPGFileType'],['../class_j_p_g_file_type.html#a5e7e481652884b8c8b8251621ad98bfb',1,'JPGFileType::JPGFileType(std::string inName=&quot;untitled&quot;)'],['../class_j_p_g_file_type.html#a41e9c1f481983977a823ecde33b01938',1,'JPGFileType::JPGFileType(const JPGFileType &amp;jfi)']]]
];
