var searchData=
[
  ['nameerror',['NameError',['../class_name_error.html',1,'']]],
  ['newitem',['NewItem',['../class_base_application.html#ab4822da88f1aae5e7d57aaf6ad962a78',1,'BaseApplication::NewItem()'],['../class_folder_type.html#af7e15bacd2e91d56effd02a4765f7f34',1,'FolderType::NewItem()']]],
  ['next',['Next',['../class_doubly_iterator.html#abc5eac06c6557c9e664c12b14e386bc6',1,'DoublyIterator::Next()'],['../class_linked_history_stack.html#a92f9628c1efb98f2f895204596d28a9a',1,'LinkedHistoryStack::Next()']]],
  ['nextistail',['NextIsTail',['../class_doubly_iterator.html#abebe8600699d31b342c2c773782afc8b',1,'DoublyIterator']]],
  ['nextptr',['NextPtr',['../class_doubly_iterator.html#af60d565590094bef89fa0fca2c075fe6',1,'DoublyIterator']]],
  ['nodetype',['NodeType',['../class_node_type.html',1,'NodeType&lt; T &gt;'],['../class_node_type.html#a6625a7c80ecf6b7c60ea9684480c0d4a',1,'NodeType::NodeType()']]],
  ['nodetype_3c_20itemtype_20_2a_20_3e',['NodeType&lt; ItemType * &gt;',['../class_node_type.html',1,'']]],
  ['nohistory',['NoHistory',['../class_no_history.html',1,'']]],
  ['noparent',['NoParent',['../class_no_parent.html',1,'']]]
];
