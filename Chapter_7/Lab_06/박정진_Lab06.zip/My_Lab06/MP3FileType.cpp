#include "MP3FileType.hpp"

void MP3FileType::Run(){

}
