#ifndef _SIMPLE_MUSIC_TYPE_H_JKIM_
#define _SIMPLE_MUSIC_TYPE_H_JKIM_


#include <string>


/**
*	@class	SimpleMusicType
*	@author	Jaemyun Kim, Byeongwoo Kim (Edited)
*	@brief	Manages music IDs and its title.
*/
class SimpleMusicType
{
public:
	/**
	*	default constructor.
	*/
	SimpleMusicType()
	{
		mMusicId = -1;
	}

	/**
	*	destructor.
	*/
	~SimpleMusicType() {}

	/**
	*	@brief	set music id.
	*	@param[in]	inId	music id.
	*/
	void setId(int inId)
	{
		mMusicId = inId;
	}

	/**
	*	@brief	get music id.
	*	@return	music id.
	*/
	int getId()
	{
		return mMusicId;
	}

	/**
	*	@brief	set music title.
	*	@param[in]	inTitle	music title.
	*/
	void setTitle(std::string inTitle)
	{
		mTitle = inTitle;
	}

	/**
	*	@brief	get music title.
	*	@return	music title.
	*/
	std::string getTitle()
	{
		return mTitle;
	}

	/**
	*	@brief	set music information.
	*	@param[in]	inId	music id.
	*	@param[in]	inTitle	music title.
	*/
	void setInfo(int inId, std::string inTitle)
	{
		mMusicId = inId;
		mTitle = inTitle;
	}

	/**
	*	@brief	display simple music information on screen.
	*/
	void DisplayAll()
	{
		std::cout << "ID : " << mMusicId << std::endl;
		std::cout << "Title : " << mTitle << std::endl;
	}


	// complete other functions...





	// complete operation overloadings...
	bool operator== (const SimpleMusicType &obj) { return 0; }
	bool operator> (const SimpleMusicType &obj) { return 0; }
	bool operator< (const SimpleMusicType &obj) { return 0; }
	bool operator>= (const SimpleMusicType &obj) { return 0; }
	bool operator<= (const SimpleMusicType &obj) { return 0; }
	
protected:
	int mMusicId;	///< Primary key
	std::string mTitle;
};


#endif // !_SIMPLE_MUSIC_TYPE_H_JKIM_