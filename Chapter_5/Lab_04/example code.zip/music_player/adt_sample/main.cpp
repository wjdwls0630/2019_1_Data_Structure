#include "MusicPlayer.h"


int main()
{
	MusicPlayer mp;
	mp.run();

	return 0;
}