#ifndef _MUSIC_PLAYER_H_JKIM_
#define _MUSIC_PLAYER_H_JKIM_


#include "MusicType.h"
#include "GenreType.h"
#include "SortedList.h"


/**
*	@class	MusicPlayer
*	@author	Jaemyun Kim, Byeongwoo Kim (Edited) 
*	@brief	Application class for the music player.
*/
class MusicPlayer
{
public:
	/**
	*	default constructor.
	*/
	MusicPlayer();

	/**
	*	destructor.
	*/
	~MusicPlayer();

	/**
	*	@brief	Test driver.
	*/
	void run();

	// complete following functions...
	int GetCommand();

	int AddMusic();

	int DeleteMusic();

	int ReplaceMusic();
	int SearchByName();
	int SearchByArtist();
	int SearchByAlbum();
	int SearchByGenre();

	int DisplayAllMusic();

	int DisplayMusicInGenre();

	int ReadDataFromFile();

	int WriteDataToFile();

protected:
	SortedList<MusicType> mMusicList;
	SortedList<GenreType> mGenreList;

	int m_Command;
};


#endif // !_MUSIC_PLAYER_H_JKIM_