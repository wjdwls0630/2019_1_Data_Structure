#ifndef _MUSIC_TYPE_H_JKIM_
#define _MUSIC_TYPE_H_JKIM_

#include <iostream>
#include <string>


/**
*	@class	MusicType
*	@author	Jaemyun Kim, Byeongwoo Kim (Edited)
*	@brief	Manages a single music file information.
*/
class MusicType
{
public:
	/**
	*	default constructor.
	*/
	MusicType()
	{
		mMusicId = -1;
	}

	/**
	*	destructor.
	*/
	~MusicType() {}

	/**
	*	@brief	set music record from keyborad.
	*/
	void setRecordFromKB()
	{
		std::cout << "ID : ";
		std::cin >> mMusicId;
		std::cout << "Title : ";
		std::cin >> mTitle;
		std::cout << "Singer : ";
		std::cin >> mSinger;
		std::cout << "Album : ";
		std::cin >> mAlbum;
		std::cout << "Genre : ";
		std::cin >> mGenre;
	}

	/**
	*	@brief	set music id.
	*	@param[in]	inId	music id.
	*/
	void setId(int inId)
	{
		mMusicId = inId;
	}

	/**
	*	@brief	get music id.
	*	@return	music id.
	*/
	int getId()
	{
		return mMusicId;
	}

	/**
	*	@brief	set music title.
	*	@param[in]	inTitle	music title.
	*/
	void setTitle(std::string inTitle)
	{
		mTitle = inTitle;
	}

	/**
	*	@brief	get music title.
	*	@return	music title.
	*/
	std::string getTitle()
	{
		return mTitle;
	}

	/**
	*	@brief	get music genre.
	*	@return	music genre.
	*/
	std::string getGenre()
	{
		return mGenre;
	}

	/**
	*	@brief	set music information.
	*	@param[in]	inId	music id.
	*	@param[in]	inTitle	music title.
	*	@param[in]	inSinger	singer.
	*	@param[in]	inAlbum	album.
	*	@param[in]	inGenre	music genre.
	*/
	void setInfo(int inId, std::string inTitle, std::string inSinger, std::string inAlbum, std::string inGenre)
	{
		mMusicId = inId;
		mTitle = inTitle;
		mSinger = inSinger;
		mAlbum = inAlbum;
		mGenre = inGenre;
	}

	/**
	*	@brief	display music information on screen.
	*/
	void DisplayAll()
	{
		std::cout << "ID : " << mMusicId << std::endl;
		std::cout << "Title : " << mTitle << std::endl;
		std::cout << "Singer : " << mSinger << std::endl;
		std::cout << "Album : " << mAlbum << std::endl;
		std::cout << "Genre : " << mGenre << std::endl;
	}

	// complete other functions...





	// complete operation overloadings...
	bool operator== (const MusicType &obj) { return 0; }
	bool operator> (const MusicType &obj) { return 0; }
	bool operator< (const MusicType &obj) { return 0; }
	bool operator>= (const MusicType &obj) { return 0; }
	bool operator<= (const MusicType &obj) { return 0; }

protected:
	int mMusicId;	///< Primary key
	std::string mTitle;
	std::string mSinger;
	std::string mAlbum;
	std::string mGenre;
};


#endif // !_MUSIC_TYPE_H_JKIM_