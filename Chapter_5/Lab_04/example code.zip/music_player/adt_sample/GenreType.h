#ifndef _GENRE_TYPE_H_JKIM_
#define _GENRE_TYPE_H_JKIM_


#include <string>
#include "MusicType.h"
#include "SimpleMusicType.h"
#include "SortedList.h"


/**
*	@class	GenreType
*	@author	Jaemyun Kim, Byeongwoo Kim (Edited)
*	@brief	Manages a genre type and music list which belongs to the genre.
*/
class GenreType
{
public:
	/**
	*	default constructor.
	*/
	GenreType()
	{
		mGenreId = -1;
	}

	/**
	*	destructor.
	*/
	~GenreType() {}

	/**
	*	@brief	set genre id.
	*	@param[in]	inGenreId	genre id.
	*/
	void setId(int inGenreId)
	{
		mGenreId = inGenreId;
	}

	/**
	*	@brief	get genre id.
	*	@return	genre id.
	*/
	int getId()
	{
		return mGenreId;
	}

	/**
	*	@brief	set genre name.
	*	@param[in]	inGenre	genre name.
	*/
	void setGenreName(std::string inGenre)
	{
		mGenre = inGenre;
	}

	/**
	*	@brief	get genre name.
	*	@return	genre name.
	*/
	std::string getGenreName()
	{
		return mGenre;
	}

	/**
	*	@brief	set genre information.
	*	@param[in]	inGenreId	genre id.
	*	@param[in]	inGenre	genre name.
	*/
	void setInfo(int inGenreId, std::string inGenre)
	{
		mGenreId = inGenreId;
		mGenre = inGenre;
	}

	/**
	*	@brief	display genre information on screen.
	*/
	void DisplayAll()
	{
		std::cout << "ID : " << mGenreId << std::endl;
		std::cout << "Genre : " << mGenre << std::endl;
	}

	/**
	*	@brief	add a music information into this genre.
	*	@param[in]	indata	music information.
	*/
	void AddMusicInGenre(SimpleMusicType indata);

	/**
	*	@brief	Displap all music information in this genre.
	*	@param[in]	list	music list.
	*/
	void DisplayMusicDetailInGenre(SortedList<MusicType> *list);


	// complete other functions...





	// complete operation overloadings...
	bool operator== (const GenreType &obj) { return 0; }
	bool operator> (const GenreType &obj) { return 0; }
	bool operator< (const GenreType &obj) { return 0; }
	bool operator>= (const GenreType &obj) { return 0; }
	bool operator<= (const GenreType &obj) { return 0; }

protected:
	int mGenreId;	///< Primary key
	std::string mGenre;

	SortedList<SimpleMusicType> mGenreMusicList;
};


#endif // !_GENRE_TYPE_H_JKIM_