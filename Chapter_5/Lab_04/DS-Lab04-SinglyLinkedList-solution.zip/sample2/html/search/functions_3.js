var searchData=
[
  ['insertitem',['InsertItem',['../class_application.html#a23be8e3cbdd32f505ff2ee50a8a8995d',1,'Application']]]
];
