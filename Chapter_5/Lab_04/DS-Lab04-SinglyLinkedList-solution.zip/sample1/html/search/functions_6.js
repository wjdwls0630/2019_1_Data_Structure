var searchData=
[
  ['makeempty',['MakeEmpty',['../class_application.html#ad721de0f33093a666e34681eb20bf2bf',1,'Application::MakeEmpty()'],['../class_linked_list.html#a544d6cfa144857d563e977420f80b383',1,'LinkedList::MakeEmpty()']]]
];
