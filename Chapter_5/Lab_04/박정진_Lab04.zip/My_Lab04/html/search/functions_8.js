var searchData=
[
  ['newitem',['NewItem',['../class_application.html#adc48fb5b5488966cd91a55915bd8a64e',1,'Application']]]
];
