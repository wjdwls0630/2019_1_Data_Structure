var searchData=
[
  ['realloc',['ReAlloc',['../class_circular_queue.html#a56f9b7778dd1e6beb7369222c25ee1a8',1,'CircularQueue::ReAlloc()'],['../class_sorted_list.html#ae8e59f4fcf13e589080fc62467d37066',1,'SortedList::ReAlloc()'],['../class_stack.html#ad05b2b619d77bf6ab37a992ef9416b7a',1,'Stack::ReAlloc()']]],
  ['replace',['Replace',['../class_sorted_list.html#a5be0efa110f2d92c203e7872fd04e62a',1,'SortedList']]],
  ['resetlist',['ResetList',['../class_s_linked_list.html#a80c0d48d73ed1ab28a0a2038d4b814dd',1,'SLinkedList::ResetList()'],['../class_sorted_list.html#aae02ef76c5185e249c3545a42e1d38c9',1,'SortedList::ResetList()']]],
  ['retrievefilebyname',['RetrieveFileByName',['../class_folder_type.html#a7afb0c8f8068f546d3de46816b60c64e',1,'FolderType']]],
  ['retrievefileptrbyname',['RetrieveFilePtrByName',['../class_folder_type.html#a8b5028594bd1152e468d1d824472c155',1,'FolderType']]],
  ['retrievefolderbyname',['RetrieveFolderByName',['../class_folder_type.html#a96ed5c758b3cd662fd431b58a8870279',1,'FolderType']]],
  ['retrievefolderptrbyname',['RetrieveFolderPtrByName',['../class_folder_type.html#a90b2b78dc63a1ca0623fa91fa512429d',1,'FolderType']]],
  ['retrieveitemsbyname',['RetrieveItemsByName',['../class_application.html#a0f839b8546a32a45653354b128859e5f',1,'Application::RetrieveItemsByName()'],['../class_folder_type.html#aa510fd12acb7cc3408e24eb28657c810',1,'FolderType::RetrieveItemsByName()']]],
  ['run',['Run',['../class_application.html#aaf09cd6cb412086dc039e28cdb059f0d',1,'Application::Run()'],['../class_file_type.html#aa761615014e9d4ce339c0163a38b1251',1,'FileType::Run()'],['../class_text_application.html#ae6ec0ddfac6060639afa12feb78d73b7',1,'TextApplication::Run()']]],
  ['runfile',['RunFile',['../class_application.html#a54b958def8f2a6a8db2f364509ca1526',1,'Application']]]
];
