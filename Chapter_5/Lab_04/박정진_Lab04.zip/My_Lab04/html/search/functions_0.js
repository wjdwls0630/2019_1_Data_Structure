var searchData=
[
  ['add',['Add',['../class_s_linked_list.html#a1e79afe7947f758d91163eedb6f66a23',1,'SLinkedList::Add()'],['../class_sorted_list.html#a6ca820f045a25002eeb63b1f4bf30428',1,'SortedList::Add()']]],
  ['addfile',['AddFile',['../class_folder_type.html#ac864eef040f0a864b08c667852dce400',1,'FolderType']]],
  ['addfolder',['AddFolder',['../class_folder_type.html#a5d43accdf973ea59d717fe7031973ff0',1,'FolderType']]],
  ['addrecentlyfile',['AddRecentlyFile',['../class_application.html#a28183900f902ed18fa8700ae15add0a7',1,'Application']]],
  ['addrecentlyfolder',['AddRecentlyFolder',['../class_application.html#a7acd727cd76a2159e268c89e29815cac',1,'Application']]],
  ['application',['Application',['../class_application.html#afa8cc05ce6b6092be5ecdfdae44e05f8',1,'Application']]]
];
