var searchData=
[
  ['textapplication',['TextApplication',['../class_text_application.html',1,'TextApplication'],['../class_text_application.html#a2cfb9e2754a0d6d7524cc16c54e678f1',1,'TextApplication::TextApplication()']]],
  ['top',['Top',['../class_stack.html#a03ba1e0bdc90f5d17149d67da48b86f1',1,'Stack']]],
  ['topptr',['TopPtr',['../class_stack.html#aea607c109a87b608f4f7551611df856e',1,'Stack']]]
];
