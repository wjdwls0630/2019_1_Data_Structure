var searchData=
[
  ['updateitemname',['UpdateItemName',['../class_application.html#ac1904e4315e050d7a4e1f814280d8a87',1,'Application']]]
];
