from tkinter import *
from tkinter import ttk, messagebox

root = Tk()
root.title("Folder Management")
root.geometry("300x200")





root.mainloop()