/**
*	@mainpage	Project_2.
*				This is a Project_2 on data structures course.<br>
*
*	@date	2019.06.09
*	@author	ParkJungJin
*/

#include "BaseApplication.hpp"

/**
*	program main function for data structures course.
*/
int main()
{
	BaseApplication app;	// Program application
	app.Run();			// run program

	return 0;
}