var searchData=
[
  ['updateitemname',['UpdateItemName',['../class_base_application.html#a6146aad1d248e5cd6cf2623591be7ecc',1,'BaseApplication']]]
];
