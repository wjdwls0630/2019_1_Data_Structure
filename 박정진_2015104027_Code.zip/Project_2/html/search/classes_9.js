var searchData=
[
  ['linkedhistorystack',['LinkedHistoryStack',['../class_linked_history_stack.html',1,'']]],
  ['linkedhistorystack_3c_20foldertype_20_2a_20_3e',['LinkedHistoryStack&lt; FolderType * &gt;',['../class_linked_history_stack.html',1,'']]],
  ['linkedqueue',['LinkedQueue',['../class_linked_queue.html',1,'']]],
  ['linkedqueue_3c_20itemtype_20_2a_20_3e',['LinkedQueue&lt; ItemType * &gt;',['../class_linked_queue.html',1,'']]]
];
