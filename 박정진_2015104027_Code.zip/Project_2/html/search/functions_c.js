var searchData=
[
  ['newitem',['NewItem',['../class_base_application.html#ab4822da88f1aae5e7d57aaf6ad962a78',1,'BaseApplication::NewItem()'],['../class_folder_type.html#af7e15bacd2e91d56effd02a4765f7f34',1,'FolderType::NewItem()']]],
  ['next',['Next',['../class_binary_iterator.html#a6b54e715b6fb042df4e905b5b575a9bf',1,'BinaryIterator::Next()'],['../class_linked_history_stack.html#a92f9628c1efb98f2f895204596d28a9a',1,'LinkedHistoryStack::Next()']]],
  ['nextistail',['NextIsTail',['../class_binary_iterator.html#a89136994482093b381e3ad042c4a3678',1,'BinaryIterator']]],
  ['nextptr',['NextPtr',['../class_binary_iterator.html#a130cff13135c1b470c6256b137425611',1,'BinaryIterator']]],
  ['nodetype',['NodeType',['../class_node_type.html#a6625a7c80ecf6b7c60ea9684480c0d4a',1,'NodeType']]]
];
