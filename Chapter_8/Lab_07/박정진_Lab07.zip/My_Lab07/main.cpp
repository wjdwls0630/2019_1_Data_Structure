/**
*	@mainpage	BinarySearchTree.
*				This is a simple example of Lab07 on data structures course.<br>
*
*	@date	2019.05.27
*	@author	ParkJungJin
*/

#include "BaseApplication.hpp"

/**
*	program main function for data structures course.
*/
int main()
{
	BaseApplication app;	// Program application
	app.Run();			// run program

	return 0;
}