var searchData=
[
  ['lq_5ffront',['lq_Front',['../class_linked_queue.html#a8da0f1f5e5e9cde435cf540c1c638354',1,'LinkedQueue']]]
];
