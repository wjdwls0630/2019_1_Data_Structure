var searchData=
[
  ['textapplication',['TextApplication',['../class_text_application.html',1,'']]],
  ['textfiletype',['TextFileType',['../class_text_file_type.html',1,'']]]
];
