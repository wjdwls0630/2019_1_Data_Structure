var searchData=
[
  ['textapplication',['TextApplication',['../class_text_application.html',1,'TextApplication'],['../class_text_application.html#af51897dce499f3b4797ff2e7a845e0bb',1,'TextApplication::TextApplication()']]],
  ['textfiletype',['TextFileType',['../class_text_file_type.html',1,'TextFileType'],['../class_text_file_type.html#abf55cac1b5866f0440418b05eac39c74',1,'TextFileType::TextFileType(std::string inName=&quot;untitled&quot;)'],['../class_text_file_type.html#aa5d7b2f8e80c2e3b05c7e13e2bb3fb70',1,'TextFileType::TextFileType(const TextFileType &amp;tfi)']]],
  ['top',['Top',['../class_linked_history_stack.html#a65836d67e4f25754df75a69c344e7d79',1,'LinkedHistoryStack']]],
  ['topptr',['TopPtr',['../class_linked_history_stack.html#a964980ea6d5ae2d0a68e1678a9c8b2ce',1,'LinkedHistoryStack']]]
];
