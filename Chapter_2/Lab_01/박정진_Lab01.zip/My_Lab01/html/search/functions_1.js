var searchData=
[
  ['comparebyid',['CompareByID',['../class_item_type.html#ac84622737d55a84113c571dcc8b6e580',1,'ItemType']]]
];
