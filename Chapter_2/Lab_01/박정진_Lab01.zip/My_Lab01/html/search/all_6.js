var searchData=
[
  ['openinfile',['OpenInFile',['../class_application.html#ad008105381d72c9753a95c4b6f8eaa48',1,'Application']]],
  ['openoutfile',['OpenOutFile',['../class_application.html#a96c9e830efe0b0f32321a1904a895b7f',1,'Application']]]
];
